import 'package:uzdst2/src/curve.dart';

class ECPoint {
  final Curve curve;
  final BigInt x;
  final BigInt y;
  final bool isInfinity;

  ECPoint(this.curve, this.x, this.y) : isInfinity = false;

  ECPoint.infinity(this.curve)
      : x = BigInt.zero,
        y = BigInt.zero,
        isInfinity = true;

  @override
  bool operator ==(Object other) =>
      other is ECPoint && x == other.x && y == other.y && isInfinity == other.isInfinity;

  @override
  int get hashCode => x.hashCode ^ y.hashCode ^ isInfinity.hashCode;

  ECPoint operator +(ECPoint other) {
    if (isInfinity) return other;
    if (other.isInfinity) return this;

    if (x == other.x && y == (other.y * BigInt.from(-1) % curve.p)) {
      return ECPoint.infinity(curve); // Point at infinity
    }

    BigInt lambda;
    if (this == other) {
      // Point doubling
      lambda = (BigInt.from(3) * x * x + curve.a) *
          (BigInt.from(2) * y).modInverse(curve.p) %
          curve.p;
    } else {
      // Point addition
      lambda = (other.y - y) * (other.x - x).modInverse(curve.p) % curve.p;
    }

    final rx = (lambda * lambda - x - other.x) % curve.p;
    final ry = (lambda * (x - rx) - y) % curve.p;

    return ECPoint(curve, rx, ry);
  }

  ECPoint operator *(BigInt k) {
    if (k == BigInt.zero || isInfinity) {
      return ECPoint.infinity(curve);
    }
    var result = ECPoint.infinity(curve); // Point at infinity
    var addend = this;

    while (k > BigInt.zero) {
      if ((k & BigInt.one) != BigInt.zero) {
        result += addend;
      }
      addend = addend + addend; // Point doubling
      k >>= 1;
    }

    return result;
  }
}




class Curve {
  final BigInt p; // The prime specifying the size of the finite field
  final BigInt a; // The coefficient a of the curve equation
  final BigInt b; // The coefficient b of the curve equation
  final BigInt n; // The order of the base point
  final BigInt gX; // x-coordinate of the base point G
  final BigInt gY; // y-coordinate of the base point G

  Curve(this.p, this.a, this.b, this.n, this.gX, this.gY);

  static final secp256k1 = Curve(
    BigInt.parse(
        'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F',
        radix: 16),
    BigInt.zero,
    BigInt.from(7),
    BigInt.parse(
        'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',
        radix: 16),
    BigInt.parse(
        '79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798',
        radix: 16),
    BigInt.parse(
        '483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8',
        radix: 16),
  );
 
  static final algo2Test = Curve(
    BigInt.parse(
        '8000000000000000000000000000000000000000000000000000000000000431',
        radix: 16),
    BigInt.from(7),
    BigInt.parse(
        '5FBFF498AA938CE739B8E022FBAFEF40563F6E6A3472FC2A514C0CE9DAE23B7E',
        radix: 16),
    BigInt.parse(
        '8000000000000000000000000000000150FE8A1892976154C59CFC193ACCF5B3',
        radix: 16),
    BigInt.from(2),
    BigInt.parse(
        '08E2A8A0E65147D4BD6316030E16D19C85C97F0A9CA267122B96ABBCEA7E8FC8',
        radix: 16),
  );
  
  /// 1.2.860.3.15.1.1.2.1.1 
  static final cryptoProAParamSet = Curve(
    BigInt.parse(
        'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd97',
        radix: 16),
    BigInt.parse(
        'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd94',
        radix: 16),
    BigInt.parse('a6', radix: 16),
    BigInt.parse(
        'ffffffffffffffffffffffffffffffff6c611070995ad10045841b09b761b893',
        radix: 16),
    BigInt.from(1),
    BigInt.parse(
        '8d91e471e0989cda27df505a453f2b7635294f2ddf23e3b122acc99c9e9f1e14',
        radix: 16),
  );
  
  /// 1.2.860.3.15.1.1.2.1.2
  static final cryptoProCParamSet = Curve(
    BigInt.parse(
        '9b9f605f5a858107ab1ec85e6b41c8aacf846e86789051d37998f7b9022d759b',
        radix: 16),
    BigInt.parse(
        '9b9f605f5a858107ab1ec85e6b41c8aacf846e86789051d37998f7b9022d7598',
        radix: 16),
    BigInt.parse('805a', radix: 16),
    BigInt.parse(
        '9b9f605f5a858107ab1ec85e6b41c8aa582ca3511eddfb74f02f3a6598980bb9',
        radix: 16),
    BigInt.from(0),
    BigInt.parse(
        '41ece55743711a8c3cbf3783cd08c0ee4d4dc440d4641a8f366e550dfdb3bb67',
        radix: 16),
  );
}



final privateKey = BigInt.parse(
    '7A929ADE789BB9BE10ED359DD39A72C11B60961F49397EEE1D19CE9891EC3B28',
    radix: 16);
  // 3221B4FBBF6D101074EC14AFAC2D4F7EFAC4CF9FEC1ED11BAE336D27D527665 2
  // 5358F8FFB38F7C09ABC782A2DF2A3927DA4077D07205F763682F3A76C9019B4F 1
final z = BigInt.parse(
    '5358F8FFB38F7C09ABC782A2DF2A3927DA4077D07205F763682F3A76C9019B4F',
    radix: 16);
//   77105C9B20BCD3122823C8CF6FCC7B956DE33814E95B7FE64FED924594DCEAB3
BigInt k = BigInt.parse(
    '77105C9B20BCD3122823C8CF6FCC7B956DE33814E95B7FE64FED924594DCEAB3',
    radix: 16);

class KeyPair {
  final BigInt privateKey;
  final ECPoint publicKey;

  KeyPair(this.privateKey, this.publicKey);
}

class Signature {
  final BigInt r;
  final BigInt s;

  Signature(this.r, this.s);
}

class Uzdst2BaseTest {
  KeyPair generateKeyPair(Curve curve) {
    final publicKey = ECPoint(curve, curve.gX, curve.gY) * privateKey;

    return KeyPair(privateKey, publicKey);
  }

  Signature sign(BigInt privateKey, Curve curve) {
    ECPoint R;
    BigInt r;
    BigInt s;

    do {
      R = ECPoint(curve, curve.gX, curve.gY) * k;
      r = R.x % curve.n;
      s = (z + r * privateKey) * k.modInverse(curve.n) % curve.n;
    } while (r == BigInt.zero || s == BigInt.zero);

    return Signature(r, s);
  }

  bool verify(Signature signature, ECPoint publicKey, Curve curve) {
    final w = signature.s.modInverse(curve.n);
    final u1 = z * w % curve.n;
    final u2 = signature.r * w % curve.n;
    final point = (ECPoint(curve, curve.gX, curve.gY) * u1) + (publicKey * u2);

    return point.x % curve.n == signature.r;
  }
}

void main() {
  var algo = Uzdst2BaseTest();
  var curve = Curve.algo2Test;
  var keyPair = algo.generateKeyPair(curve);
  Signature s = algo.sign(keyPair.privateKey, curve);
  print("${s.r}\n${s.s}");
  print(algo.verify(s, keyPair.publicKey, curve));
}
// 29700980915817952874371204983938256990422752107994319651632687982059210933395
// 574973400270084654178925310019147038455227042649098563933718999175515839552


